export default function add(x, y){
    return x + y
}
// console.log('add function')