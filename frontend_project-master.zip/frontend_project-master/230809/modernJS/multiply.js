export default function multiply(x,y){
    return x * y
}
// console.log('multiply function')