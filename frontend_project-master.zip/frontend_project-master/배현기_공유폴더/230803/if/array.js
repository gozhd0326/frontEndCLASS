const pokemon = ['피카츄', '파이리','꼬부기', '망나뇽','이상해씨']

for(let i = 0;i < pokemon.length;i++){
    console.log(pokemon[i])
}
// console.log(pokemon[0])
// console.log(pokemon[1])
// console.log(pokemon[2])
