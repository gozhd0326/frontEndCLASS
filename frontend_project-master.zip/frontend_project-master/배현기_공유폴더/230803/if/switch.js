const food = '짬뽕';

switch(food){
    case "짬뽕":
        console.log('왠일이냐 짬뽕이라니')
        break;
    case "생선구이":
        console.log('너 생선싫다며')
        break;
    case "김치찌개":
        console.log("김치찌개라니 너 정신차렸구나")
        break;
    case "떡볶이":
        console.log('또 떡볶이냐.그만 좀 해라')
        break;
    default:
        console.log('막내 휴가라 다행이다')
        break;
}
