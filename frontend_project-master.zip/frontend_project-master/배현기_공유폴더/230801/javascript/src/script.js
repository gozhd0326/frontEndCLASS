// do : let은 내용을 바꿔도 된다.
let variables = 'content';
let content = variables + '추가된 컨텐츠'
console.log(content)
// variables = 'content'
// variables = 'Another Content' 

// don't : const는 내용을 바꾸면 안된다.
// const content = "content"
// content = 'another' 
// console.log(content)

// const name = "이름"
// const numberOne = 5
// const number = "3"
// const add = numberOne + number
// const subtract = numberOne - number
// const multiply = numberOne * number
// const divide = numberOne / number
/** 
 * 문자열 -> 숫자로 형변환
 * Number(), parseInt(), +number(변수 이름 앞에 +)
 * */ 
// const result = numberOne + Number(number)
// console.log(result)  
// console.log(add)  
// console.log(subtract)  
// console.log(multiply)  
// console.log(divide)  
/**
 * 주석을 여러줄에 걸쳐서
 * 작성할때는 이렇게 씁니다.
 */
// 한줄로 작성할때는 이렇게 씁니다.
// 매줄마다 새롭게 슬래시를 두번 넣어서
// 작성해줘야합니다.
