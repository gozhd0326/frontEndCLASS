const stat = document.querySelectorAll('stat')
console.log(stat)