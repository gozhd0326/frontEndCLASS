const side = document.getElementById('sidebar')
const button = document.getElementById('trigger')
console.log(button)

