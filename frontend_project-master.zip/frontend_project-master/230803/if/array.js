// console.log('array')
// console.log(pokemon[0])
// console.log(pokemon[1])
// console.log(pokemon[2])
// console.log(pokemon[3])
// const pokemon = ['피카츄', '라이츄', '파이리', '꼬부기', '버터풀', '라도란', '이상해씨', '메타몽', '잠만보','망나뇽']

// for (let i = '0'; i < pokemon.length; i++) {
//     console.log(pokemon[i])
// }
