const data =document.getElementById('data')
data.textContent = data.dataset.content
