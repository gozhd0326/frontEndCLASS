//  vavicon : title 아이콘
// var, let, const === 변수
// let, const
// do :let 값을 바꿀 수 있다.
let username = '홍길동' 
username = '동길홍'

// don't : const는 값을 바꿀 수 없다.
let nmae = '강아지'
// console.log(username)
// console.log(name)

// boolean - 참,또는 거짓
let value = true
value = false
// console.log(value)

// null
// let nullValue;
let nullValue = null;

// undefind
let undefValue;
// console.log(undefValue)

// number
let numberValue = 11;

// string

// undefined
let undefValue;
// console.log(undefValue)

//number
let numberValue = 11;

// object
let objValue ={ }

// +.-.*,/ , %
let a = 1;
let b = 2;
a = a + b
a += b
console.log(a)

// 증가 연산자,  감소 연사자
let x = 1;
const y = x++
// console.log{x, y}

let valueOne = 2;
const valueTwo = --valueOne
console.log(valueOne, valueTwo);

