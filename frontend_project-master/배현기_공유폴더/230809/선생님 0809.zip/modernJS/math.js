export default function add(x, y) {   
    return x + y
}
export function multiply(x,y){
    return x * y
}