export default function add (x, y) {
    console.log('add function')
    return x + y
}